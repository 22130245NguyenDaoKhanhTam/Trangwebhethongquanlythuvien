package Model.BO;

import java.sql.SQLException;

import Model.Bean.Users;
import Model.DAO.UserDAO;

public class UserBO {
	UserDAO userDAO = new UserDAO();

	public Users getAccount(String username, String password) throws ClassNotFoundException, SQLException {
		Users user = new Users();
		user.setUsername(username);
		user.setPassword(password);
		return userDAO.getUser(username, password);
	}
}
